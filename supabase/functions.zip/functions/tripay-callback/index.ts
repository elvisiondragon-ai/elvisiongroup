import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.54.0';
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS'
};
serve(async (req)=>{
  console.log('🚀 Tripay callback Edge Function started');
  console.log('📝 Method:', req.method);
  console.log('📝 URL:', req.url);
  // Handle CORS
  if (req.method === 'OPTIONS') {
    console.log('✅ CORS preflight handled');
    return new Response('ok', {
      headers: corsHeaders
    });
  }
  // Only accept POST
  if (req.method !== 'POST') {
    console.log('❌ Method not allowed:', req.method);
    return new Response(JSON.stringify({
      success: false,
      error: 'Method not allowed'
    }), {
      status: 405,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  }
  try {
    console.log('📥 Parsing request body...');
    const payload = await req.json();
    console.log('📥 VPS callback payload received:', JSON.stringify(payload, null, 2));
    console.log('🔧 Initializing Supabase client...');
    const supabase = createClient(Deno.env.get('SUPABASE_URL') ?? '', Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '');
    console.log('✅ Supabase client initialized');
    // Extract data from VPS payload (your VPS sends this format)
    const tripayReference = payload.tripay_reference || payload.reference;
    const paymentStatus = payload.status;
    const paymentMethod = payload.payment_method || 'Unknown';
    if (!tripayReference) {
      console.log('❌ Missing tripay_reference in payload');
      return new Response(JSON.stringify({
        success: false,
        error: 'Missing tripay_reference'
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    console.log('🔄 Processing callback with data:');
    console.log('  - tripay_reference:', tripayReference);
    console.log('  - payment_status:', paymentStatus);
    console.log('  - payment_method:', paymentMethod);
    // Call your RPC function
    console.log('🔄 Calling process_tripay_payment_callback RPC...');
    const { data: result, error } = await supabase.rpc('process_tripay_payment_callback', {
      p_tripay_reference: tripayReference,
      p_payment_status: paymentStatus,
      p_payment_method: paymentMethod
    });
    console.log('🔄 RPC call completed');
    console.log('📊 RPC Result:', result);
    if (error) {
      console.error('❌ RPC Error:', error);
      return new Response(JSON.stringify({
        success: false,
        error: error.message,
        details: error
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    console.log('✅ Callback processed successfully');
    // Send email notification if payment successful
    if (result && result.success && result.action === 'subscription_activated') {
      try {
        console.log('📧 Sending success email notification...');
        const { data: subscription } = await supabase.from('pro_subscriptions').select('user_email, subscription_type, amount_paid, currency').eq('id', result.subscription_id).single();
        if (subscription) {
          await supabase.functions.invoke('send-payment-email', {
            body: {
              userEmail: subscription.user_email,
              amount: subscription.amount_paid,
              currency: subscription.currency,
              reference: tripayReference,
              subscriptionType: subscription.subscription_type,
              paymentMethod: paymentMethod,
              status: 'success'
            }
          });
          console.log('📧 Email sent to:', subscription.user_email);
        }
      } catch (emailError) {
        console.log('📧 Email failed (non-critical):', emailError.message);
      }
    }
    return new Response(JSON.stringify({
      success: true,
      data: result
    }), {
      status: 200,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  } catch (error) {
    console.error('💥 Edge Function error:', error);
    console.error('💥 Error stack:', error.stack);
    return new Response(JSON.stringify({
      success: false,
      error: 'Internal server error',
      details: error.message
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  }
});
